import scipy.io as sio
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
#######################################################
## Setting parameters ##

learning_rate = 1e-4
Input_sqr = 8 ## Change this when you chane the size of covariance.
channel = 2
n_labels = 5 ## change it to number of area
keep_prob = 0.5

num_epochs = 50 ## number of epoch
num_batches = 32 ## size of batch, depend on your GPU memory

## end of Setting parameters ##
#######################################################
## dealing with input data (training & testing) ##

## training dataset initialize
string_input1 = 'train_dataset/train_Covariance'
string_input2 = 'Covariance'
string_output1 = 'train_dataset/train_Label'
string_output2 = 'Label'
    
#input    size: (data_num,Input_sqr,Input_sqr,channel)
mat = sio.loadmat(string_input1)
train_input = mat[string_input2]
train_input = np.float32(train_input)
#output    size: (data_num,1)
mat = sio.loadmat(string_output1)
train_output = mat[string_output2]       
train_output = np.float32(train_output)

## test dataset initialize
string_input3 = 'test_dataset/test_Covariance'
string_input4 = 'Covariance'
string_output3 = 'test_dataset/test_Label'
string_output4 = 'Label'
    
#input    size: (data_num,Input_sqr,Input_sqr,channel)
mat = sio.loadmat(string_input3)
test_input = mat[string_input4]
test_input = np.float32(test_input)

#output    size: (data_num,1)
mat = sio.loadmat(string_output3)
test_output = mat[string_output4]       
test_output = np.float32(test_output)

## end of dealing with input data (training & testing) ##
########################################################################
## Define model ##
## you can choose your lose at Line71 ##

model = models.Sequential([
    ##
    ## design your model here
    ##
    
    ])
print(model.summary())
## compile and train the model ##
Adam = tf.keras.optimizers.Adam(lr=learning_rate)
model.compile(optimizer=Adam,
              loss = tf.keras.losses.CategoricalCrossentropy(from_logits=False),
              metrics=['accuracy']) 
    # maybe use loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
    
## end of Define model ##
########################################################################
## Callback setting ##
## Callback 可用可不用，若不需使用請在model.fit中刪去callbacks ##

# class CustomCallback(tf.keras.callbacks.Callback): # you can custom your callback like this
#     def on_epoch_end(self, epoch, logs=None):
#         if epoch%5 == 0:
#             print('epoch:%d, loss:%f' %(epoch,logs.get('loss')))

## the following is create a folder to save checkpoint
ckpt_folder = "./ckpt"
if not os.path.exists(ckpt_folder):
    os.mkdir(ckpt_folder)
## here is the checkpoint callback, it will save the weight of best val_accuracy
## We will load_weight after training (at Line148 load best weight to evaluate test_dataset)
model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(
    filepath=ckpt_folder,
    save_weights_only=True,
    monitor='val_accuracy',
    mode='max',
    save_best_only=True)

## it is EarlyStopping, if your model not improve performace in "patience" epoch, it will stop
model_StopEarly_callback = tf.keras.callbacks.EarlyStopping(
    monitor='val_accuracy',
    min_delta=0.005,    ## it can decide by you
    patience=10,        ## it can decide by you
    verbose=0,
    mode='max',
    baseline=None,
    restore_best_weights=False,
)

## end of Callback setting ##
########################################################################
## start to train model ##
train_history = model.fit(train_input, train_output,batch_size=num_batches, epochs=num_epochs,
                          validation_data=(test_input, test_output), 
                          callbacks=[model_checkpoint_callback, model_StopEarly_callback])
# train_history = model.fit(train_input, train_output,batch_size=num_batches, epochs=num_epochs,
#                           validation_data=(test_input, test_output))

########################################################################
## plot Accuracy ##

history_dict = train_history.history
plt.figure(1)
plt.clf()
acc = history_dict['accuracy']
val_acc = history_dict['val_accuracy']
epochs = range(1, len(acc) + 1)
plt.plot(epochs, acc, 'b', label='Training Accuracy')
plt.plot(epochs, val_acc, 'r', label='Validation Accuracy')
plt.title('Training Accuracy')
plt.xlabel('Iteration')
plt.ylabel('Accuracy rate')
plt.legend(loc='lower right')

## plot loss
loss = history_dict['loss']
epochs = range(1, len(loss)+1)
plt.figure(2)
plt.plot(epochs, loss, 'b', label='Training loss')
plt.title('Learning Curve')
plt.xlabel('Iteration')
plt.ylabel('Loss')
plt.legend(['Cross entropy'], loc='upper right')
plt.show()

## end of plot Accuracy ##
########################################################################
## evaluate loss value of test dataset ##

model.load_weights(ckpt_folder)
test_loss = model.evaluate(test_input, test_output)
print("test loss:", test_loss)

## end of evaluate loss value of test dataset ##
########################################################################












